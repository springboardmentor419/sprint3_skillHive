import { Component } from '@angular/core';

@Component({
  selector: 'app-shcedule-dialog',
  standalone: true,
  imports: [],
  templateUrl: './shcedule-dialog.component.html',
  styleUrl: './shcedule-dialog.component.css'
})
export class ShceduleDialogComponent {

}
